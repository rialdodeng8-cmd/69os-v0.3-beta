#!/bin/sh
set -e

mkdir -p ~/69OS-EXPORT
tar -czf ~/69OS-EXPORT/69OS-backup.tar.gz \
  -C "$HOME" 69os

echo "69OS backup created!"
ls -lh ~/69OS-EXPORT/69OS-backup.tar.gz

cd ~/69OS-EXPORT
python3 -m http.server 8000
