import os,json,random,shutil
D=os.path.expanduser("~/69os")
S=D+"/saves.json"
try:
 d=json.load(open(S))
except:
 d={"name":"Player","games":0,"wins":0}
def save():
 json.dump(d,open(S,"w"))
def tic():
 b=[" "]*9
 while True:
  os.system("clear")
  print("69OS TIC TAC TOE")
  for r in range(3):
   print(" | ".join(b[i] if b[i]!=" " else str(i+1) for i in range(r*3,r*3+3)))
   if r<2: print("--+---+--")
  lines=[(0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6)]
  w=lambda p:any(all(b[i]==p for i in l) for l in lines)
  if w("X") or w("O") or " " not in b:
   print("YOU WIN!" if w("X") else "BOT WINS!" if w("O") else "DRAW!")
   d["games"]+=1
   d["wins"]+=int(w("X"))
   save()
   input("Enter...")
   return
  try:
   n=int(input("Square 1-9, 0=quit: "))
   if n==0:return
   if n not in range(1,10) or b[n-1]!=" ":continue
   b[n-1]="X"
   if w("X"):continue
   free=[i for i in range(9) if b[i]==" "]
   for p in ("O","X"):
    move=None
    for i in free:
     b[i]=p
     if w(p):move=i
     b[i]=" "
     if move is not None:break
    if move is not None:break
   b[move if move is not None else random.choice(free)]="O"
  except:pass
def word():
 words=["python","planet","gaming","rocket","kernel"]
 w=random.choice(words); seen=set(); tries=7
 while tries:
  print(" ".join(c if c in seen else "_" for c in w))
  if all(c in seen for c in w):
   print("YOU WIN!");d["wins"]+=1;d["games"]+=1;save();input();return
  c=input("Letter (0 quits): ").lower()
  if c=="0":return
  if len(c)!=1 or not c.isalpha() or c in seen:continue
  seen.add(c)
  if c not in w:tries-=1
 print("Word:",w);d["games"]+=1;save();input()
def guess():
 n=random.randint(1,100)
 while True:
  try:g=int(input("Guess 1-100 (0 quits): "))
  except:continue
  if g==0:return
  if g==n:
   print("CORRECT!");d["wins"]+=1;d["games"]+=1;save();input();return
  print("Too low!" if g<n else "Too high!")
def games():
 while True:
  print("\n69OS GAMES\n1 Tic-Tac-Toe\n2 Word Guess\n3 Number Guess\n4 Dice Battle\n0 Back")
  c=input("games> ")
  if c=="1":tic()
  elif c=="2":word()
  elif c=="3":guess()
  elif c=="4":
   a,b=random.randint(1,6),random.randint(1,6)
   print("You:",a,"Bot:",b)
   print("You win!" if a>b else "Bot wins!" if b>a else "Draw!")
   d["games"]+=1;d["wins"]+=int(a>b);save()
  elif c=="0":return
def main():
 while True:
  os.system("clear")
  print("\033[95m 69OS \033[96mTERMINAL EDITION\033[0m")
  print("Welcome,",d["name"])
  print("1 Games\n2 System info\n3 Change username\n4 Backup\n0 Shutdown")
  c=input("69OS > ")
  if c=="1":games()
  elif c=="2":
   print("Games:",d["games"],"Wins:",d["wins"]);input("Enter...")
  elif c=="3":
   n=input("Username: ")
   if n:d["name"]=n;save()
  elif c=="4":
   os.makedirs(D+"/backups",exist_ok=True)
   shutil.copy2(__file__,D+"/backups/69os.py")
   shutil.copy2(S,D+"/backups/saves.json") if os.path.exists(S) else save()
   print("Backup created!");input("Enter...")
  elif c=="0":save();return
if __name__=="__main__":main()
