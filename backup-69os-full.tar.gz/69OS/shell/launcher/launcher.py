#!/usr/bin/env python3

import tkinter as tk

root = tk.Tk()
root.title("69OS Launcher")
root.geometry("700x500")
root.configure(bg="#1A1B2E")

title = tk.Label(
    root,
    text="69OS",
    font=("Arial", 32, "bold"),
    fg="#FFF0F6",
    bg="#1A1B2E"
)
title.pack(pady=30)

search = tk.Entry(
    root,
    font=("Arial", 18),
    bg="#FFF0F6",
    fg="#2E2E3A"
)
search.pack(padx=50, fill="x")

apps = [
    "Files",
    "Terminal",
    "Browser",
    "Text Editor",
    "Media",
    "Software",
    "Settings"
]

for app in apps:
    tk.Button(
        root,
        text=app,
        font=("Arial", 15),
        bg="#FF9EC4",
        fg="#2E2E3A",
        relief="flat",
        padx=20,
        pady=8
    ).pack(pady=4)

root.mainloop()
