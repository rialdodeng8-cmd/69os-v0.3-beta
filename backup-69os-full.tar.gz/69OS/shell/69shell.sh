#!/bin/sh

while true; do
    clear

    echo "╔══════════════════════════════════════╗"
    echo "║         WELCOME TO 69OS DESKTOP     ║"
    echo "╠══════════════════════════════════════╣"
    echo "║                                      ║"
    echo "║  1) Files                            ║"
    echo "║  2) Terminal                         ║"
    echo "║  3) Settings                         ║"
    echo "║  4) About 69OS                       ║"
    echo "║  5) Shutdown Desktop                 ║"
    echo "║                                      ║"
    echo "╚══════════════════════════════════════╝"
    echo
    printf "69OS > "
    read choice

    case "$choice" in
        1)
            echo
            echo "Files"
            ls -la ~
            ;;
        2)
            echo
            echo "69OS Terminal"
            echo "Type 'exit' to return."
            /bin/sh
            ;;
        3)
            echo
            echo "69OS Settings"
            echo "Theme: Cotton Candy Cyber"
            echo "Pink:  #FF9EC4"
            echo "Blue:  #7EC8E3"
            echo "Dark:  #1A1B2E"
            ;;
        4)
            echo
            echo "69OS 0.1"
            echo "Debian-based desktop project"
            echo "Theme: Cotton Candy Cyber"
            ;;
        5)
            echo
            echo "Closing 69OS Desktop..."
            break
            ;;
        *)
            echo
            echo "Unknown option."
            ;;
    esac

    echo
    printf "Press Enter to continue..."
    read pause
done
